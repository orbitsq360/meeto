<footer class="main-footer">
    <strong>{{ __('Copyright') }} &copy; {{ date('Y') }}
        {{ getSetting('APPLICATION_NAME') }}.</strong>
    {{ __('All rights reserved') }}
    <div class="float-right d-none d-sm-inline-block">
        <b>{{ __('Version') }}</b> {{ getSetting('VERSION') }}
    </div>
</footer>